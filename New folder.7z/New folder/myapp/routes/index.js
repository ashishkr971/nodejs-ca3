var express = require("express");
var router = express.Router();

/* GET home page. */
router.get("/", function (req, res, next) {
  res.render("home", { title: "Express" });
});
router.get("/home", function (req, res, next) {
  res.render("home", { title: "Express" });
});
router.get("/cart", function (req, res, next) {
  res.render("cart", { title: "Express" });
});
router.get("/payment", function (req, res, next) {
  res.render("payment", { title: "Express" });
});
router.get("/logib", function (req, res, next) {
  res.render("login", { title: "Express" });
});
module.exports = router;
